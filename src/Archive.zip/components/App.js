import React, { Component } from "react";
import "../App.css";
import Nav from "./Nav";
import hogs from "../porkers_data";
// import hogImages
import HelloWorld from "./HelloWorld";
import HogCard from "./HogCard"

class App extends Component {

  componentDidMount() {
    console.log(hogs)
  }

  render() {
    return (
      <div className="App">
        <Nav />
        {hogs.map((piggy, idx) =>
          <HogCard
            key={idx}
            {...piggy}
          />
        )}
        <HelloWorld />
      </div>
    );
  }
}

export default App;
