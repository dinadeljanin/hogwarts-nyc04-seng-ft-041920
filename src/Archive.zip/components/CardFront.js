import React, { Component } from 'react'

export default class CardFront extends Component {
  render() {
    return (
      const piggyUrl = `${this.props.name.toLowerCase().split(" ").join("_")}.jpg`

      // <div className="container">
        <div className="ui card">
          <div className="image">
            <img src={require(`../hog-imgs/${piggyUrl}`)} alt={this.props.name}/>
          </div>
        </div>
      {/* </div> */}
    )
  }
}
