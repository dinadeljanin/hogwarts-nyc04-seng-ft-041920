import React, { Component } from 'react'

export default class HogCard extends Component {
  render() {
    return (
      <div className="container"></div>
      // <div className="container">
      //   <div className="ui card">
      //
      //     <div className="content">
      //       <a className="header">{this.props.name}</a>
      //       <div className="meta">
      //         <span className="date">{this.props.specialty}</span>
      //       </div>
      //     </div>
      //     <div className="extra content">
      //       <a>
      //         <i className="user icon"></i>
      //         Weight
      //         {this.props.weight}
      //       </a>
      //       <a>
      //         <i className="user icon"></i>
      //         Greased
      //         {this.props.greased}
      //       </a>
      //       <a>
      //         <i className="user icon"></i>
      //         Highest Medal Achieved
      //         {this.props['highest medal achieved']}
      //       </a>
      //     </div>
      //   </div>
      // </div>
    )
  }
}
